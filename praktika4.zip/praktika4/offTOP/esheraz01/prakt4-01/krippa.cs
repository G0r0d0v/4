﻿namespace prakt4_01
{
    class krippa : kreppa
    {
        public int kluch;
        public krippa(string name, int bolt, int _kluch) : base(name, bolt)
        {
            kluch = _kluch ;
    }


    }
}
